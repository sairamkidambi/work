import { Injectable } from "@angular/core";
import { HttpClient, HttpResponse, HttpHandler } from "@angular/common/http";
import { catchError, tap } from "rxjs/operators";
import { throwError, Subject, BehaviorSubject } from "rxjs";
import { User } from "./user.model";
import { Router } from "@angular/router";

export interface AuthResponse { //after seeing the docs we already what it returns so build interface and returing the same in signup method
    kind: string,
    idToken: string,
    email: string,
    refreshToken: string,
    expiresIn: string,
    localId: string,
    registered?: string

}
@Injectable({ providedIn: 'root' })

export class AuthServiceLogin {
    private expiryTimeOut: any;
    user = new BehaviorSubject<User>(null);
    constructor(private http: HttpClient, private res: HttpHandler, private router: Router) { }

    

    private authentication(email: string, userId: string, token: string, expiresIn: number) {
        const expDate = new Date(new Date().getTime() + expiresIn * 1000);// expires returns seconds in string so coverting into ms by *1000
        const user = new User(email, userId, token, expDate);
        this.user.next(user);
        localStorage.setItem('userData', JSON.stringify(user));// this will make to amintain local session so even if we refresh page data is persistence.
        this.autoLogout(expiresIn * 1000);
    }

    autoLogout(expiryDuration: number) {
        this.expiryTimeOut = setTimeout(() => {
            this.logout();
        }, expiryDuration); // cahnge expiryduration to 2000 and check in theapplciaiton tab
    }
    logout() {
        this.user.next(null);
        this.router.navigate(['/auth']);
        //localStorage.clear(); if we dont want to clear all the item then use remove item;
        localStorage.removeItem('userData');
        if (this.expiryTimeOut) {
            clearTimeout(this.expiryTimeOut);
        }
        this.expiryTimeOut = null;
    }
    login(email: string, pwd: string) {
        return this.http.post<AuthResponse>('https://www.googleapis.com/identitytoolkit/v3/relyingparty/verifyPassword?key=AIzaSyDYkUzBAPGCEuz7yeBQoyz_wKxTvY9m2lI',
            { email: email, password: pwd, returnSecureToken: true }).pipe(catchError(error => {
                let errorMes = "Unknown error occured";
                if (!error.error || !error.error.error.message) {
                    return throwError(errorMes);
                }
                switch (error.error.error.message) {
                    case 'EMAIL_NOT_FOUND':
                        errorMes = "Email doesn't exist";
                        break;
                    case 'USER_DISABLED':
                        errorMes = "The user account has been disabled by an administrator.";
                        break;
                    case 'INVALID_PASSWORD':
                        errorMes = "The password is incorrect.";
                        break;
                }

                return throwError(errorMes);
            }), tap(resData => {
                this.authentication(resData.email, resData.localId, resData.idToken, +resData.expiresIn)
            }))
    }


}
