import { Report } from './report.modal';
import { Userinfo } from '../shared/user-details.model';
import { UserDetails } from '../shared/user-details.service';
import { Injectable } from '@angular/core';

@Injectable()
export class ReportService {
    constructor(private userDetails: UserDetails) { }
    private reportData: Report[]= [new Report(this.userDetails.getUsersById(0).id, '12A34', true, false, new Date('2016-06-28 03:00:00'),'No Damages reported. Please undergo timely maintainsnce',true,false),
    new Report(this.userDetails.getUsersById(1).id, '314B45', true, false, new Date('2016-06-28 11:00:00'),'All body parts are in condition and running fine',true,false),
    new Report(this.userDetails.getUsersById(2).id, '243C47', true, false, new Date('2016-06-29 11:05:00'),'All body parts are in condition and running fine',true,false),
    new Report(this.userDetails.getUsersById(3).id, '12A34', false, true, new Date('2016-06-30 04:00:00'),'Clutch plates damage reported and engine misfire causing frequently',true,false),
    new Report(this.userDetails.getUsersById(3).id, '12A34', false, false, new Date('2016-06-30 04:00:00'),'Clutch plates damage reported and engine misfire causing frequently',true,false)


];

    getFullReportData() {
        console.log(this.reportData);
        return this.reportData.slice();
       
    }
    getFullReportDatabyId(i: number) {
        console.log(this.reportData);
        return this.reportData[i];
       
    }
    public searchUser(name){
       
        const userDetail = this.userDetails.getUsers();
        if(name){
        
          for(var i = 0;i< userDetail.length;i++){
              if((userDetail[i].firstName).toUpperCase === name.toUpperCase){
                return userDetail[i];
              }else if(this.reportData[i].truckid === name){
                return this.reportData[i];
              }
          }
        }
            }

}