

export class User{

    constructor(public email: string,public id: string,private _token: string,private _tokenExpiryDate: Date){

    }

get token() {// here getter also means that user cant overwrite this // this is still not a method it's property. JS getter
    if(!this._tokenExpiryDate || new Date() > this._tokenExpiryDate){// token is not valied
return null;
    }
return this._token;
}
}