import { Userinfo } from './user-details.model';


 export class MarkerModal{
     constructor(public lat: number, public lang: number, public label?: string, public user?: Userinfo,public iconUrl?: any){

     }
 }