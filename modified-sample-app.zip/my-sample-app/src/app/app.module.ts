import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AccumulationChartModule } from '@syncfusion/ej2-angular-charts';
import { PieSeriesService, AccumulationDataLabelService,AccumulationLegendService,CategoryService,LineSeriesService, LegendService } from '@syncfusion/ej2-angular-charts';
import { ChartsModule } from '@progress/kendo-angular-charts';
import { CheckBoxModule,ButtonModule  } from '@syncfusion/ej2-angular-buttons';
import { MultiSelectAllModule } from '@syncfusion/ej2-angular-dropdowns';
import { AutoCompleteModule } from '@syncfusion/ej2-angular-dropdowns';

import { DropDownListModule } from '@syncfusion/ej2-angular-dropdowns';
import { NumericTextBoxModule } from '@syncfusion/ej2-angular-inputs';
import { AppComponent } from './app.component';
import { AuthComponent } from './auth/auth.component';
import { HomeComponent } from './home/home.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import{ HttpModule} from '@angular/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HeaderComponent } from './header/header.component';
import { AppRouting } from './app-routing.module';
import { LoadingSpinner } from './shared/loading-spinner/loading-spinner.component';
import { AuthIterceptor } from './auth/auth-intercpetor.service';
import { AgmCoreModule } from '@agm/core';
import { UserDetails } from './shared/user-details.service';
import { MarkerService } from './shared/marker.service';
import { ReportsComponent } from './reports/reports.component';
import { ReportListComponent } from './reports/report-list/report-list.component';
import { ReportItemComponent } from './reports/report-list/report-item/report-item.component';
import { ReportService } from './reports/reports.service';
import { ReportDetailsComponent } from './reports/report-details/report-details.component';
import { ReportStartComponent } from './reports/report-start/report-start.component';
import { AlertsComponent } from './alerts/alerts.component';
import { AlertService } from './alerts/alerts.service';
import { PieDataComponent } from './pie-data/pie-data.component';
import { AlertSeriesComponent } from './alert-series/alert-series.component';
@NgModule({
  declarations: [
    AppComponent,
    AuthComponent,
    HomeComponent,
    HeaderComponent,
    LoadingSpinner,
    ReportsComponent,
    ReportListComponent,
    ReportItemComponent,
    ReportDetailsComponent,
    ReportStartComponent,
    AlertsComponent,
    PieDataComponent,
    AlertSeriesComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRouting,
    HttpClientModule,
    HttpModule,
    FormsModule,
    AccumulationChartModule,
    AutoCompleteModule,
    DropDownListModule,
    CheckBoxModule,
    ButtonModule,
    NumericTextBoxModule,
    ChartsModule,
    MultiSelectAllModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyCbVLCfC55Doi3s-8d_yIAeuLl6TBjh6eU'
    })
  ],
  providers: [ UserDetails,
    MarkerService,ReportService,AlertService,
    {provide:HTTP_INTERCEPTORS,useClass:AuthIterceptor,multi:true},
    AccumulationDataLabelService,PieSeriesService,CategoryService,LineSeriesService,AccumulationLegendService,LegendService],
  bootstrap: [AppComponent]
})
export class AppModule { }
