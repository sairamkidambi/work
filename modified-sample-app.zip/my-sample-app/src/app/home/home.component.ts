import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { Userinfo } from '../shared/user-details.model';
import { UserDetails } from '../shared/user-details.service';
import { MarkerService } from '../shared/marker.service';
import { MapsAPILoader, AgmMap } from '@agm/core';
import { NgForm } from '@angular/forms';
import { ReportService } from '../reports/reports.service';
import { AutoCompleteComponent } from '@syncfusion/ej2-angular-dropdowns';
import { CheckBoxSelectionService, FilteringEventArgs } from '@syncfusion/ej2-angular-dropdowns';
import { Query } from '@syncfusion/ej2-data';
import { EmitType } from '@syncfusion/ej2-base';

//declare var google: any;
interface marker {
  lat: number;
  lng: number;
  label?: string;
  iconUrl?: any;
  id?: number;
  firstName?: string;
}

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  encapsulation: ViewEncapsulation.None
})

// just an interface for type safety.

export class HomeComponent implements OnInit {
  public mode: string;
  userDetail: Userinfo[];
  username: string;
  map: google.maps.Map;
  searchField: string;
  searchTextMatch: boolean;
  id: number;
  storeValueId: number;
  @ViewChild('form', { static: true }) slForm: NgForm;
  @ViewChild('autoComplete', { static: true }) public obj: AutoCompleteComponent;
  public data: any;

  constructor(private userInfo: UserDetails, private markerService: MarkerService, private reportService: ReportService) {
    this.userDetail = this.userInfo.getUsers();
  }
  icon = {
    url: 'https://image.flaticon.com/icons/svg/75/75780.svg',
    scaledSize: {
      width: 35,
      height: 35
    }
  }
  markers: marker[] = [
    {
      lat: 13.0170,
      lng: 77.704,
      label: 'A',
      iconUrl: this.icon,
      id: 0


    },
    {
      lat: 13.0250,
      lng: 77.5340,
      label: 'B',
      iconUrl: this.icon,
      id: 2
    },
    {
      lat: 12.9784,
      lng: 77.6408,
      label: 'C',
      iconUrl: this.icon,
      id: 3
    },
    {
      lat: 12.9920,
      lng: 77.5943,
      label: 'D',
      iconUrl: this.icon,
      id: 4
    },
    {
      lat: 12.9970,
      lng: 77.4943,
      label: 'E',
      iconUrl: this.icon,
      id: 5
    }
  ]


  public fields: Object = { value: 'name' };
  public watermark: string = 'Select Vehicle';

  ngOnInit() {
    this.mode = 'CheckBox';


    this.userDetail = this.userInfo.getUsers();
    console.log(this.userDetail);


    setTimeout(() => {
      const searchVal = this.reportService.getFullReportData();
      const userDet = this.userInfo.getUsers();
      this.data = [
        { name: searchVal[0].truckName, truckiD: searchVal[0].truckid, driverName: userDet[0].firstName },
        { name: searchVal[1].truckName, truckiD: searchVal[1].truckid, driverName: userDet[1].firstName },
        { name: searchVal[2].truckName, truckiD: searchVal[2].truckid, driverName: userDet[2].firstName },
        { name: searchVal[3].truckName, truckiD: searchVal[3].truckid, driverName: userDet[3].firstName }

      ];
      if (this.userDetail) {

        for (var i = 0; i < this.markers.length; i++) {
          this.markers[i].firstName = this.userDetail[i].firstName;
          console.log(this.markers[i].firstName);
        }
      }
    }, 1500);

  }
  title: string = 'Cab Locator';
  lat: number = 12.9375;
  lng: number = 77.4472;
  onMapClick(event) {
    console.log(event)
  }
  mapReady(map) {
    this.map = map;
  }
  public onFiltering: EmitType<any> = (e: FilteringEventArgs) => {
    let oldData: any = this.data;
    let checkFlag = false;
    //frame the query based on search string with filter type.
    const query = (e.text != "");
    if (query) {
      for (var i = 0; i < this.data.length; i++) {

        if (this.data[i].name === e.text) {
          checkFlag = true;
        }
      }
    }
    else {
      this.fields = { value: 'name' }
      this.markers[this.storeValueId].iconUrl = this.icon;
    }
    if (!checkFlag) {
      this.setCenter(e.text);
      this.fields = { value: 'driverName' }
      if (this.searchTextMatch) {
        for (var i = 0; i < this.data.length; i++) {

          if ((this.data[i].driverName).toUpperCase() === e.text.toUpperCase()) {
            this.data = this.data[i];
this.fields = { value: 'driverName' }
          
          }
        }
      }
    }
    this.searchTextMatch = false;

    //pass the filter data source, filter query to updateData method.
    // this.setCenter(query);
  };
  onvalueSelect(event) {
    console.log(event);
    const value = event.itemData.truckiD;
    this.setCenter(value);
  }
  setCenter(value) {
    const icon = {
      url: 'https://image.flaticon.com/icons/svg/75/75780.svg',
      scaledSize: {
        height: 55,
        width: 55
      }
    };
    //e.preventDefault();
    if (value) {
      var valueRes = this.reportService.searchUser(value);
      if (valueRes) {
      this.id = valueRes.id > 3 ? 2 : valueRes.id;
        this.storeValueId = valueRes.id;
        this.markers[valueRes.id].iconUrl = icon;
        console.log(new google.maps.LatLng(this.markers[valueRes.id].lat, this.markers[valueRes.id].lng))
        this.map.setCenter(new google.maps.LatLng(this.markers[valueRes.id].lat, this.markers[valueRes.id].lng));
      }
      this.searchTextMatch = true;
    }


  }
  onKeyStroke(event) {
    if (event.data === null) { this.markers[this.id].iconUrl = this.icon; }

  }
  onSelectRemoval(event) {
    console.log(event);
    const value = event.itemData.truckiD;
    if (value) {
      var valueRes = this.reportService.searchUser(value);
      this.id = valueRes.id;
      this.markers[valueRes.id].iconUrl = this.icon;
    }

  }
}
