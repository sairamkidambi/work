import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { MapsAPILoader, AgmMap } from '@agm/core';
import { NgForm } from '@angular/forms';
//import { } from '@types/googlemaps';


interface Marker {
  lat: number;
  lng: number;
  label?: string;
  draggable: boolean;
}
interface Location {
  lat: number;
  lng: number;
  viewport?: Object;
  zoom: number;
  address_level_1?: string;
  address_level_2?: string;
  address_country?: string;
  address_zip?: string;
  address_state?: string;
  marker?: Marker;
}

@Component({
  selector: 'app-report-start',
  templateUrl: './report-start.component.html',
  styleUrls: ['./report-start.component.css']
})
export class ReportStartComponent implements OnInit {
  geocoder: any;
  public location: Location = {
    lat: 51.678418,
    lng: 7.809007,
    marker: {
      lat: 51.678418,
      lng: 7.809007,
      draggable: true
    },
    zoom: 5
  };
  
 

  constructor(public mapsApiLoader: MapsAPILoader) {
    // this.mapsApiLoader = mapsApiLoader;
    
    // this.mapsApiLoader.load().then(() => {
    //   this.geocoder = new google.maps.Geocoder();
    // });
  }
  ngOnInit() {
    
  }
  updateOnMap() {

  }
  // mapReady(map){
  //   this.map = map;
  // }
  // setCenter(form: NgForm){
  //   //e.preventDefault();
  //   console.log(new google.maps.LatLng(13.0170, 77.704))
  //   this.map.setCenter(new google.maps.LatLng(13.0170, 77.704));
  // }

  


}
