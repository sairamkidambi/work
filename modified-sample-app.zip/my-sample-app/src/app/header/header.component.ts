import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Subscription } from 'rxjs';
import { AuthServiceLogin } from '../auth/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  isAuthenticated=false;
  subscription: Subscription;
  constructor(private authService: AuthServiceLogin,private router: Router) { }

  ngOnInit() {
    this.subscription=   this.authService.user.subscribe(user=>{
      this.isAuthenticated = !user? false:true; //console.log(!!user) issame of this terinary expression
      console.log(!!user);
      console.log(!user);
       });
  }
  onLogout(){
    this.authService.logout();
   // this.router.navigate(['/auth']);
}
}
