import { Component, OnInit } from '@angular/core';
import { ReportService } from '../reports.service';
import { Report } from '../report.modal';

@Component({
  selector: 'app-report-list',
  templateUrl: './report-list.component.html',
  styleUrls: ['./report-list.component.css']
})
export class ReportListComponent implements OnInit {
reportData: Report[];
  constructor(private reportService: ReportService) { }

  ngOnInit() {
    this.reportData= this.reportService.getFullReportData();
  }

}
