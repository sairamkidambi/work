import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-alert-series',
  template:`
  <kendo-chart [valueAxis]='valueAxis' (legendItemClick)="onLegendItemClick($event)">
    <kendo-chart-title text="Traffic ticket history"></kendo-chart-title>
    <kendo-chart-category-axis>
        <kendo-chart-category-axis-item
            [categories]="['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul']"
            [title]="{ text: 'Months' }">
        </kendo-chart-category-axis-item>
    </kendo-chart-category-axis>
    <kendo-chart-series>
      
      <kendo-chart-series-item type="line" name="Alex" [data]="[1,2,4,0,0,2]">
      </kendo-chart-series-item>
      <kendo-chart-series-item type="line" name="John Mark" [data]="[0,0,0,0,0,1]">
      </kendo-chart-series-item>
    </kendo-chart-series>
  </kendo-chart>
`,
  styleUrls: ['./alert-series.component.css']
})
export class AlertSeriesComponent implements OnInit {
  public valueAxis: Object;
  public primaryYAxis: Object;
  public chartData: Object[];
  @Output() onAlertClick = new EventEmitter();
  constructor() { }

  ngOnInit() {
  this.valueAxis={
    min: 0,
    max: 5,
    majorUnit: 1
}
  }

 public onLegendItemClick(event): void{
    console.log(event);
    this.onAlertClick.emit(event);
  }

}
