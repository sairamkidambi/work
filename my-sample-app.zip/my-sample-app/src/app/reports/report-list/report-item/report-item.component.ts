import { Component, OnInit, Input } from '@angular/core';
import { Report } from '../../report.modal';

@Component({
  selector: 'app-report-item',
  templateUrl: './report-item.component.html',
  styleUrls: ['./report-item.component.css']
})
export class ReportItemComponent implements OnInit {
@Input() data: Report;
@Input() indexNum: number;
cabBreakDownIcon: string;
  constructor() { }

  ngOnInit() {
    console.log(this.data);
    if(this.data.breakDownStatus){
      this.cabBreakDownIcon="https://image.flaticon.com/icons/svg/1274/1274317.svg";
    }else{
      this.cabBreakDownIcon="https://image.flaticon.com/icons/svg/1896/1896899.svg";
    }
      
  }

}
