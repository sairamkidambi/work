
export class AlertInfo{
    constructor(public name:string,public cabNumber: string,public description: string,public fullDescription: string,public icon: string){}
        
    
    }