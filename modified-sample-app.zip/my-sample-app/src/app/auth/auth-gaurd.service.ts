import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router, UrlTree } from "@angular/router";
import { Observable } from "rxjs";
import { AuthServiceLogin } from './auth.service';
import { take, map, tap } from 'rxjs/operators';
@Injectable({ providedIn: 'root' })
export class AuthGuardLogin implements CanActivate{
    constructor(private authService: AuthServiceLogin, private router:Router){}
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
        return this.authService.user.pipe(take(1), 
            map(user =>
        {
            console.log(!!user);
            return !!user;
           

        }),
            tap(isAuth=>{
            if(!isAuth){//urlnavigate
           this.router.navigate(['/auth']);
            }

                })
        )
}
}