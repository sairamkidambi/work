import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { AuthComponent } from './auth/auth.component';
import { HomeComponent } from './home/home.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import{ HttpModule} from '@angular/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HeaderComponent } from './header/header.component';
import { AppRouting } from './app-routing.module';
import { LoadingSpinner } from './shared/loading-spinner/loading-spinner.component';
import { AuthIterceptor } from './auth/auth-intercpetor.service';
import { AgmCoreModule } from '@agm/core';
import { UserDetails } from './shared/user-details.service';
import { MarkerService } from './shared/marker.service';
import { ReportsComponent } from './reports/reports.component';
import { ReportListComponent } from './reports/report-list/report-list.component';
import { ReportItemComponent } from './reports/report-list/report-item/report-item.component';
import { ReportService } from './reports/reports.service';
import { ReportDetailsComponent } from './reports/report-details/report-details.component';
import { ReportStartComponent } from './reports/report-start/report-start.component';
import { AlertsComponent } from './alerts/alerts.component';
import { AlertService } from './alerts/alerts.service';
@NgModule({
  declarations: [
    AppComponent,
    AuthComponent,
    HomeComponent,
    HeaderComponent,
    LoadingSpinner,
    ReportsComponent,
    ReportListComponent,
    ReportItemComponent,
    ReportDetailsComponent,
    ReportStartComponent,
    AlertsComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRouting,
    HttpClientModule,
    HttpModule,
    FormsModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyCbVLCfC55Doi3s-8d_yIAeuLl6TBjh6eU'
    })
  ],
  providers: [ UserDetails,MarkerService,ReportService,AlertService,{provide:HTTP_INTERCEPTORS,useClass:AuthIterceptor,multi:true}],
  bootstrap: [AppComponent]
})
export class AppModule { }
