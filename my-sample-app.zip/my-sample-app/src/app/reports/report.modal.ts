

export class Report{
constructor(public id:number,public truckid: string,public driverStatus: boolean,public breakDownStatus:boolean,public createdAt: Date,public desc: string,public onDuty: boolean, public offDuty:boolean){}
}