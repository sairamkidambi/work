import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { AuthServiceLogin } from './auth/auth.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  encapsulation:ViewEncapsulation.None
})
export class AppComponent implements OnInit {
  showHeader: boolean;
  title = 'my-sample-app';
  constructor(private authService: AuthServiceLogin){}
  ngOnInit(){
    this.authService.user.subscribe(user=>{
      if(!user)
      {
        this.showHeader = false;
      }else{
        this.showHeader = true;
      }
    })
  }
}
