import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { AlertService } from './alerts.service';
import { AlertInfo } from './alerts-detail.model';

@Component({
  selector: 'app-alerts',
  templateUrl: './alerts.component.html',
  styleUrls: ['./alerts.component.css'],
  encapsulation:ViewEncapsulation.None
})
export class AlertsComponent implements OnInit {
 
  constructor(private alertService:AlertService) { }
  alertContent: AlertInfo;
alertInfo: AlertInfo[];
alertHistory=false;
isActive(i){
  
}
  ngOnInit() {
 this.alertInfo= this.alertService.getAlertInfo();
 var modal = document.getElementById("myModal");
//  console.log(this.alertInfo)
window.onclick = function(event) {

  if (event.target == modal) {
    modal.style.display = "none";
  }

  }}
  onAlertClick(i:number){
this.alertContent = this.alertService.getAlertInfoById(i);
console.log(this.alertContent);
this.alertHistory=!this.alertHistory;
  }
  setDisplay(){

   

this.alertHistory=!this.alertHistory;
    
  }

}
