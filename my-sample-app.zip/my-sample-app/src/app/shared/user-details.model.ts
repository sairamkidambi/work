

export class Userinfo{
    constructor(public firstName: string,public lastName: string,public contact: number,public id: number){}
}