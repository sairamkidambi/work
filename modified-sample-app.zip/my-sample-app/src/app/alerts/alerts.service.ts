import { Injectable } from '@angular/core';
import { AlertInfo } from './alerts-detail.model';
import { UserDetails } from '../shared/user-details.service';
import { ReportService } from '../reports/reports.service';

@Injectable()
export class AlertService{
    constructor(private userDetails: UserDetails, private reportService: ReportService){}
private alertDetails: AlertInfo[]=[
 new AlertInfo(this.userDetails.getUsersById(0).firstName,this.reportService.getFullReportDatabyId(0).truckid,'Over speeding alert','Cab driver named'+this.userDetails.getUsersById(0).firstName+'bearing the cab number'+this.reportService.getFullReportDatabyId(0).truckid+'has been violated the speed limit.','https://image.flaticon.com/icons/svg/179/179386.svg'),
 new AlertInfo('John Mark',this.reportService.getFullReportDatabyId(1).truckid,'Customer Complaint alert','Cab driver named'+this.userDetails.getUsersById(1).firstName+'bearing the cab number'+this.reportService.getFullReportDatabyId(1).truckid+'has been denied service for far destination .','https://image.flaticon.com/icons/svg/1484/1484573.svg'),
 new AlertInfo('Luie','','Trip Cancellation alert','Luie'+'has just cancelle the trip '+'expecting for shorter duration .','https://image.flaticon.com/icons/svg/458/458594.svg')

]
    
public getAlertInfo(){
    console.log(this.alertDetails)
    return this.alertDetails;
}
public getAlertInfoById(i){
    console.log(this.alertDetails)
    return this.alertDetails[i];
}
}