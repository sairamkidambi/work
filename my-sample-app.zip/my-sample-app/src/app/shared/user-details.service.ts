import { Userinfo } from './user-details.model';


export class UserDetails{
    private userDetails: Userinfo[] = [
        new Userinfo('Alex','Stuart',9000714120,1),
        new Userinfo('Koushik','kumar',8143588990,2),
        new Userinfo('Lalitha','Priya',8921345667,3),
        new Userinfo('John','Mark',8921345667,4)
    ]

   public getUsers(){
        return  this.userDetails;
    }
    public getUsersById(i:number){
        return  this.userDetails[i];
    }
 
}