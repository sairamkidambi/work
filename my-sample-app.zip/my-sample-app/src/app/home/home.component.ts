import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { Userinfo } from '../shared/user-details.model';
import { UserDetails } from '../shared/user-details.service';
import {MarkerService } from '../shared/marker.service';
import { MapsAPILoader, AgmMap } from '@agm/core';
import { NgForm } from '@angular/forms';
import { ReportService } from '../reports/reports.service';

//declare var google: any;
 interface marker {
	lat: number;
	lng: number;
	label?: string;
  iconUrl?: any;
id?: number;
firstName?: string;
}

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  encapsulation:ViewEncapsulation.None
})

// just an interface for type safety.

export class HomeComponent implements OnInit {
  
  userDetail:Userinfo[];
  username: string;
  map: google.maps.Map;
  searchField: string;
  id:number;
  @ViewChild('form',{static:true}) slForm: NgForm;
  
  constructor(private userInfo: UserDetails, private markerService: MarkerService, private reportService: ReportService){
    this.userDetail = this.userInfo.getUsers();
  }
  icon = {
    url:'https://image.flaticon.com/icons/svg/75/75780.svg',
    scaledSize: {
      width: 35,
      height: 35
    }
  }
  markers: marker[] = [
	  {
		  lat: 13.0170,
		  lng: 77.704,
		  label: 'A',
      iconUrl:this.icon,
      id:1
     
      
	  },
	  {
		  lat: 13.0250,
		  lng: 77.5340,
		  label: 'B',
      iconUrl:this.icon,
      id:2
    },
    {
		  lat: 12.9784,
		  lng: 77.6408,
		  label: 'C',
      iconUrl:this.icon,
      id:3
    },
    {
		  lat: 12.9920,
		  lng: 77.5943,
		  label: 'D',
      iconUrl:this.icon,
      id:4
	  }
  ]
 

  ngOnInit() {
    this.userDetail = this.userInfo.getUsers();
    console.log(this.userDetail);
     

setTimeout(() => {
  if(this.userDetail){
    
for(var i = 0 ; i < this.markers.length; i++){
  this.markers[i].firstName = this.userDetail[i].firstName;
 console.log(this.markers[i].firstName);
}
  }
}, 1500);

  }
  title: string = 'Cab Locator';
  lat: number = 12.9375;
  lng: number = 77.4472;
  onMapClick(event){
console.log(event)
  }
  mapReady(map){
    this.map = map;
  }
  setCenter(form: NgForm){
    const icon = {
      url:'https://image.flaticon.com/icons/svg/75/75780.svg',
      scaledSize: {
        height: 55,
        width: 55
      }
    };
    //e.preventDefault();
    const searchInputvalue = form.value.driverName;
    if(searchInputvalue){
     var value= this.reportService.searchUser(searchInputvalue);
     this.id = value.id;
    console.log(value.id);

    }
    this.markers[value.id].iconUrl= icon;
    console.log(new google.maps.LatLng(13.0170, 77.704))
    this.map.setCenter(new google.maps.LatLng(this.markers[value.id].lat, this.markers[value.id].lng));
  }
  onKeyStroke(event){
    if(event.data === null){this.markers[this.id].iconUrl = this.icon;}
    
  }
}
