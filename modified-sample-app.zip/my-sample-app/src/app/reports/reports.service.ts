import { Report } from './report.modal';
import { Userinfo } from '../shared/user-details.model';
import { UserDetails } from '../shared/user-details.service';
import { Injectable } from '@angular/core';

@Injectable()
export class ReportService {
  onDutyDrivers:number = 1;
  offDutyDrivers:number = 1;
  breakDownCount: number = 1;
    constructor(private userDetails: UserDetails) { }
    private reportData: Report[]= [new Report(this.userDetails.getUsersById(0).id,'Alto', 'MP00000', true, false, new Date('2016-06-28 03:00:00'),'No Damages reported. Please undergo timely maintainsnce',true,false),
    new Report(this.userDetails.getUsersById(1).id,'Thar45343', 'MP09SS1010', true, false, new Date('2016-06-28 11:00:00'),'All body parts are in condition and running fine',true,false),
    new Report(this.userDetails.getUsersById(2).id,'Range Rover 007', 'DL007', true, false, new Date('2016-06-29 11:05:00'),'All body parts are in condition and running fine',true,false),
    new Report(this.userDetails.getUsersById(3).id,'My Jupiter', 'DL107', false, true, new Date('2016-06-30 04:00:00'),'Clutch plates damage reported and engine misfire causing frequently',false,true),
    new Report(this.userDetails.getUsersById(4).id,'Land Rover X40', 'KS0134', false, false, new Date('2016-06-30 04:00:00'),'Clutch plates damage reported and engine misfire causing frequently',false,true)


];

    getFullReportData() {
        console.log(this.reportData);
        return this.reportData.slice();
       
    }
    getFullReportDatabyId(i: number) {
        console.log(this.reportData);
        return this.reportData[i];
       
    }
    public searchUser(name){
       
        const userDetail = this.userDetails.getUsers();
        if(name){
        
          for(var i = 0;i< userDetail.length;i++){
              if((userDetail[i].firstName).toUpperCase() === name.toUpperCase()){
                return userDetail[i];
              }else if((this.reportData[i].truckid).toUpperCase() === name.toUpperCase()){
                return this.reportData[i];
              }
          }
        }
            }
        
}