import { NgModule} from '@angular/core';
import { Router,RouterModule, Routes } from '@angular/router';
import { AuthComponent } from './auth/auth.component';
import { HomeComponent } from './home/home.component';
import { ReportsComponent } from './reports/reports.component';
import { ReportDetailsComponent } from './reports/report-details/report-details.component';
import { ReportStartComponent } from './reports/report-start/report-start.component';
import { AuthGuardLogin } from './auth/auth-gaurd.service';
import { AlertsComponent } from './alerts/alerts.component';


const routes: Routes = [
    {path:'home', component:HomeComponent,canActivate:[AuthGuardLogin]},
    {path:'auth', component:AuthComponent,},
    {path:'reports', component:ReportsComponent,canActivate:[AuthGuardLogin],children:[
      {path:'', component: ReportStartComponent} ,
      {path:':id', component: ReportDetailsComponent} 
    ]
  },
  {path:'alerts', canActivate:[AuthGuardLogin],component:AlertsComponent}
  ];
  @NgModule({
    imports:[
        RouterModule.forRoot(routes)
    ],
    exports:[RouterModule]
    })
  export class AppRouting{


}