import { Component, OnInit } from '@angular/core';
import { Subscription, Observable } from 'rxjs';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthResponse, AuthServiceLogin } from './auth.service';


@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.css']
})
export class AuthComponent implements OnInit {
  isLogin=true;
  isLoading = false;
error: string = null;

  constructor(private router: Router,private authService: AuthServiceLogin) { }

  ngOnInit() {
  }
  onSwitchMode(){
    this.isLogin = !this.isLogin;
  }

  onSubmit(form: NgForm){
    let authObs: Observable<AuthResponse>;
    this.isLoading = true;
    if(!form.valid){
      return; //extra security step if hacker possibly changes disable from dev tools.so, this step will not provide login
    }
const email= form.value.email;
const pwd= form.value.password;
if(this.isLogin){

authObs=this.authService.login(email,pwd)

}

authObs.subscribe(resData=>{
  console.log(resData);
  this.isLoading=false;
  this.router.navigate(['/home'])
},errorRes=>{
  console.log(errorRes);
  this.isLoading=false;
  
  this.error=errorRes;
  //this.showAlert(this.error);

})



form.reset();
  }
  onLogout(){
   
   // this.router.navigate(['/auth']);
}

}
