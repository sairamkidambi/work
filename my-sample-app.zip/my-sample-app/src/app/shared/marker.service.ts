import { MarkerModal } from './marker.modal';

import { Userinfo } from './user-details.model';
import { UserDetails } from './user-details.service';
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
@Injectable()
export class MarkerService {
    markersChanged = new Subject<MarkerModal[]>();
userDetailData: Userinfo[] =  this.userDetails.getUsers();
    icon = {
        url:'https://image.flaticon.com/icons/svg/75/75780.svg',
        scaledSize: {
          width: 20,
          height: 20
        }
      }
    private markerData: MarkerModal[] = [
        new MarkerModal(13.0170,77.704,'A', this.userDetailData[0],this.icon),
        // new MarkerModal(13.0250,77.5340,'B', this.userDetails.getUsersById(1),this.icon),
        // new MarkerModal(12.9784,77.6408,'C', this.userDetails.getUsersById(2),this.icon),
        // new MarkerModal(12.9920, 77.5943,'D', this.userDetails.getUsersById(3),this.icon)
    ]
    constructor(private userDetails: UserDetails){}

    getMarkerService(){
        return this.markerData;
      //  return this.markersChanged.next(this.markerData.slice());
    }
}