import { Component, OnInit } from '@angular/core';
import { ReportService } from '../reports.service';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { Report } from '../report.modal';
@Component({
  selector: 'app-report-details',
  templateUrl: './report-details.component.html',
  styleUrls: ['./report-details.component.css']
})
export class ReportDetailsComponent implements OnInit {
  report: Report;
  id:number;
  showHintText: boolean;
  constructor(private reportService: ReportService,private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    this.route.params.subscribe((params: Params)=>{
      this.id= +params['id'];
      this.report = this.reportService.getFullReportDatabyId(this.id);
      console.log(this.report);
      
    });
    
  }

}
