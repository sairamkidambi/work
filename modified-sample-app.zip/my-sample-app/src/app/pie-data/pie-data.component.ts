import { Component, OnInit } from '@angular/core';
import { NumberSymbol } from '@angular/common';
import { ReportService } from '../reports/reports.service';

@Component({
  selector: 'app-pie-data',
  template:
  `<ejs-accumulationchart id="chart-container" [legendSettings]='legendSettings'>
      <e-accumulation-series-collection>
          <e-accumulation-series  legendShape='Rectangle' name='data' [dataSource]='piedata' xName='x' yName='y'  innerRadius='80%' [dataLabel]='datalabel'></e-accumulation-series>
      </e-accumulation-series-collection>
  </ejs-accumulationchart>`,
  styleUrls: ['./pie-data.component.css']
})
export class PieDataComponent implements OnInit {
  public piedata: Object[];
  public datalabel: Object;
  onDutyDrivers:number = 0;
  offDutyDrivers:number = 0;
  breakDownCount: number = 0;
  public legendSettings= {
    visible: true,
    position: 'Top' ,
    // position: 'Custom',
    // location: { x: 200, y: 40 }
 };;
  
  ngOnInit(){
   const dataValue= this.getDriverDutyCount();
    console.log(dataValue);
    setTimeout(() => {
      //console.log(this.legendSettings.visible+"undefined");
      this.piedata = [
        { x: 'Off Duty Drivers', y: dataValue['offDutyDrivers'], text: 'Off Duty Drivers' }, { x: 'On Duty Drivers', y: dataValue['onDutyDrivers'], text: 'On Duty Drivers' },{ x: 'Break down cabs', y: dataValue['breakDownStatus'], text: 'Break down cabs' }];
        this.datalabel = { visible: true, position: 'Outside',name: 'text' };
    }, 500);
    
  }
  constructor(private reportService: ReportService) { }
getDriverDutyCount(){
  const arr=[];
  const reportData=  this.reportService.getFullReportData();
    for(var i=0;i<reportData.length;i++){

if(reportData[i].breakDownStatus){
 arr["breakDownStatus"]= ++this.breakDownCount;
 arr["offDutyDrivers"]= ++this.offDutyDrivers;
}else if(reportData[i].offDuty){
  arr["offDutyDrivers"]= ++this.offDutyDrivers;
}else if(reportData[i].onDuty){
  arr["onDutyDrivers"] = ++this.onDutyDrivers;
    }
      
  }

  return arr;
}
scrollEnd(event){
  console.log(event);
}
}
